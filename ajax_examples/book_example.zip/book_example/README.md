# create an online book reader
## when a user clicks a thumbnail of a book, download and display that book's cover page and the text of it
## when a user clicks the 'like' button, update a file that contains how many likes that book has

```
+---------+
|■ ■ ■ ■ ■|
|---------|
|+-------+|
||       ||
|+-------+|
|✓        |
|         |
|chapter 1|
+---------+
```

- 1 route & view to display home page
- 1 route to dynamically fetch the book contents
- 1 route to process the like button
